Place all contents in this directory, to your root local webserver directory.

Shell v1.2.2 | Xevrac